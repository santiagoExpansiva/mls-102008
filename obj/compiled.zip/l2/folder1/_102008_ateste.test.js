/// <mls shortName="ateste" project="102008" enhancement="_blank" folder="folder1" />
export const integrations = [];
export const tests = [];
