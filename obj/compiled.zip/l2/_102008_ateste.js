/// <mls shortName="ateste" project="102008" enhancement="_100554_enhancementLit" groupName="other" /> 
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
import './_102008_folder1/ateste';
let SimpleGreeting = class SimpleGreeting extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`ateste-102008{color:#006ab3}`);
        this.name = new Date(Date.now()).toString();
    }
    handleConfirm(e) {
        console.info(e.detail);
    }
    showGreetingAlert() {
        alert(`Hello world Lucas 10`);
    }
    render() {
        return html `
        <div class="cls1">
            <h1>Hello world Lucas 10</h1>
            <button @click="${this.showGreetingAlert}">Show Greeting</button>
        </div>
        <folder1--ateste-102008></folder1--ateste-102008>`;
    }
};
__decorate([
    property()
], SimpleGreeting.prototype, "name", void 0);
SimpleGreeting = __decorate([
    customElement('ateste-102008')
], SimpleGreeting);
export { SimpleGreeting };
