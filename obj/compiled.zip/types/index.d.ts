declare module "_102008_ateste.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102008_ateste" {
    import { CollabLitElement } from '_100554_collabLitElement';
    import './_102008_folder1/ateste';
    export class SimpleGreeting extends CollabLitElement {
        name: string;
        handleConfirm(e: CustomEvent): void;
        showGreetingAlert(): void;
        render(): any;
    }
}
declare module "_102008_cteste.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102008_designSystem" {
    import { IDesignSystemTokens } from './_100554_designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
declare module "_102008_dteste.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "folder1/_102008_ateste.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "folder1/_102008_ateste" {
    import { CollabLitElement } from '_100554_collabLitElement';
    export class SimpleGreeting extends CollabLitElement {
        name: string;
        handleConfirm(e: CustomEvent): void;
        render(): any;
    }
}
