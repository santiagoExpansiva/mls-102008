declare module "_102008_ateste" {
    import { CollabLitElement } from './_100554_collabLitElement';
    export class SimpleGreeting extends CollabLitElement {
        name: string;
        handleConfirm(e: CustomEvent): void;
        showGreetingAlert(): void;
        render(): any;
    }
}
declare module "_102008_designSystem" {
    import { IDesignSystemTokens } from './_100554_designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
